LANTERN: A Lightweight Trajectory-Set Planner for Quadrotor Navigation

Anonymous review supplement. 12 November 2026.

LANTERN_RAL_video_English.mp4; 197.17 s; 1920x1080; 30 fps.
MP4 / H.264 / AAC stereo 48 kHz. English narration with instrumental BGM.
Self-contained; play at normal speed with a standard MP4 player.
Contact the corresponding author through the submission system.

English subtitles are permanently visible in the MP4. English.srt is also included.
