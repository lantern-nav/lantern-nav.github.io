LANTERN: A Lightweight Trajectory-Set Planner for Quadrotor Navigation

Anonymous review supplement. 13 November 2026.

LANTERN_RAL_video_English.mp4; 245.93 s; 1920x1080; 30 fps.
MP4 / H.264 / AAC stereo 48 kHz. English narration with instrumental BGM.
Self-contained; play at normal speed with a standard MP4 player.
Contact the corresponding author through the submission system.

English subtitles are permanently visible in the MP4. English.srt is also included.

Music: "Horizons" by Scott Buckley.
Released under CC BY 4.0.
Source: https://www.scottbuckley.com.au/library/horizons/
Artist: https://www.scottbuckley.com.au/
License: https://creativecommons.org/licenses/by/4.0/
Changes: excerpt, equalization, gentle leveling, fades and narration mix.
