# LANTERN Browser Demo

Anonymous authors.

Run `python serve.py --port 8788`, then open the printed address followed by `demo.html`. Real ONNX inference runs locally. Randomize uses screened demo seeds. These are qualitative examples with ideal tracking, separate from the paper benchmarks. See Model and environment for the complete assumptions.

Third-party licenses are in assets/vendor/ and assets/lucide-LICENSE.
